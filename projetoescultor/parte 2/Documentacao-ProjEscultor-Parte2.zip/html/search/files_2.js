var searchData=
[
  ['figurageometrica_2ecpp_84',['figurageometrica.cpp',['../figurageometrica_8cpp.html',1,'']]],
  ['figurageometrica_2eh_85',['figurageometrica.h',['../figurageometrica_8h.html',1,'']]]
];
