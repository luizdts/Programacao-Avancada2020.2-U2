var searchData=
[
  ['r_133',['r',['../struct_voxel.html#a06872ec79b836120b551a848968c0f1b',1,'Voxel::r()'],['../class_escultor.html#a7efc6bee81fc6e12aac18f39252ca33a',1,'Escultor::r()'],['../class_figura_geometrica.html#a0a4f57efb1a6c525c8aeee34c92e7eab',1,'FiguraGeometrica::r()']]]
];
