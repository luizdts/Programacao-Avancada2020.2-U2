var searchData=
[
  ['a_126',['a',['../struct_voxel.html#a3ce2579eb0a9f09a07112ce7498a638e',1,'Voxel::a()'],['../class_escultor.html#ac38328e0f27ddf7be575a7508567424d',1,'Escultor::a()'],['../class_figura_geometrica.html#ae7c8a027fcec3c357265b90458a4d165',1,'FiguraGeometrica::a()']]]
];
