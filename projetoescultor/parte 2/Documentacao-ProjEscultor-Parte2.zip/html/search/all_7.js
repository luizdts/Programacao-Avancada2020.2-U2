var searchData=
[
  ['interpretador_25',['Interpretador',['../class_interpretador.html',1,'Interpretador'],['../class_interpretador.html#a12d844a7ab8d634e96b57971c9aedd9e',1,'Interpretador::Interpretador()']]],
  ['interpretador_2ecpp_26',['interpretador.cpp',['../interpretador_8cpp.html',1,'']]],
  ['interpretador_2eh_27',['interpretador.h',['../interpretador_8h.html',1,'']]],
  ['ison_28',['isOn',['../struct_voxel.html#a6fbe8bd53f64685ac4210726d40fc775',1,'Voxel']]]
];
