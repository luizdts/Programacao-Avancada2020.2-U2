var searchData=
[
  ['setcolor_114',['setColor',['../class_escultor.html#a0ed0cf0ce64c797f9d41dbc0f0d2a9df',1,'Escultor']]]
];
