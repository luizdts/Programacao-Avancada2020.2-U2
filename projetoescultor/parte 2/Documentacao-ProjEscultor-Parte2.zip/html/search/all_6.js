var searchData=
[
  ['g_21',['g',['../struct_voxel.html#a27c0da1ed2ff430401d23ff171612a73',1,'Voxel::g()'],['../class_escultor.html#af0f8431add4402f8d086b1a9b148d6f9',1,'Escultor::g()'],['../class_figura_geometrica.html#a51930549bcb90d016b824f10f95df355',1,'FiguraGeometrica::g()']]],
  ['getx_22',['getX',['../class_interpretador.html#a8341b27aa03340bf905e554b46a84657',1,'Interpretador']]],
  ['gety_23',['getY',['../class_interpretador.html#a1e48d783f61727efcf9a6462bb44488b',1,'Interpretador']]],
  ['getz_24',['getZ',['../class_interpretador.html#a10d90a857863d836320afbb3adec8745',1,'Interpretador']]]
];
