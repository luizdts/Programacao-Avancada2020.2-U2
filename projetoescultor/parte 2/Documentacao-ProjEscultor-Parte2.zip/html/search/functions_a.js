var searchData=
[
  ['_7ecutbox_116',['~cutBox',['../classcut_box.html#ad221aa42f4a7693b697d1492c9c23c29',1,'cutBox']]],
  ['_7ecutellipsoid_117',['~cutEllipsoid',['../classcut_ellipsoid.html#ae4877ae289158979d34ac8c19caeb7fe',1,'cutEllipsoid']]],
  ['_7ecutsphere_118',['~cutSphere',['../classcut_sphere.html#acc41c446f3ae38d39b18b7b08e34f236',1,'cutSphere']]],
  ['_7ecutvoxel_119',['~cutVoxel',['../classcut_voxel.html#a7bcbee6a6842c7b359980f5d6fe29921',1,'cutVoxel']]],
  ['_7eescultor_120',['~Escultor',['../class_escultor.html#ae3112e055c4cdd5494e12bb35555d402',1,'Escultor']]],
  ['_7efigurageometrica_121',['~FiguraGeometrica',['../class_figura_geometrica.html#a40ce7fb4b6cbf0cbe3852e342c739988',1,'FiguraGeometrica']]],
  ['_7eputbox_122',['~putBox',['../classput_box.html#aa8bddb88c536421ee9ee7aec7e73a060',1,'putBox']]],
  ['_7eputellipsoid_123',['~putEllipsoid',['../classput_ellipsoid.html#ae20016b0dcc08bdcb3ea86a41dba108a',1,'putEllipsoid']]],
  ['_7eputsphere_124',['~putSphere',['../classput_sphere.html#aeca8caff4f0c76f50a375159a12300f5',1,'putSphere']]],
  ['_7eputvoxel_125',['~putVoxel',['../classput_voxel.html#a4e2f82887ec1c1d88bf7905a0ea19f68',1,'putVoxel']]]
];
