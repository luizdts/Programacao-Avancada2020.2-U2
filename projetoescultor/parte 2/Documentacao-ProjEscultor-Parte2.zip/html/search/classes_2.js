var searchData=
[
  ['figurageometrica_67',['FiguraGeometrica',['../class_figura_geometrica.html',1,'']]]
];
