var searchData=
[
  ['getx_104',['getX',['../class_interpretador.html#a8341b27aa03340bf905e554b46a84657',1,'Interpretador']]],
  ['gety_105',['getY',['../class_interpretador.html#a1e48d783f61727efcf9a6462bb44488b',1,'Interpretador']]],
  ['getz_106',['getZ',['../class_interpretador.html#a10d90a857863d836320afbb3adec8745',1,'Interpretador']]]
];
