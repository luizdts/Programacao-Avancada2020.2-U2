var searchData=
[
  ['nx_31',['nx',['../class_escultor.html#a7739ca9a5de47becad04c505edc5a782',1,'Escultor']]],
  ['ny_32',['ny',['../class_escultor.html#af40660ee1f0abbe651e9a2a74376b7c5',1,'Escultor']]],
  ['nz_33',['nz',['../class_escultor.html#ad3f3edf599ee06fdaa36c021f0e9be6d',1,'Escultor']]]
];
