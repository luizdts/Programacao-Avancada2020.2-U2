var searchData=
[
  ['b_127',['b',['../struct_voxel.html#a5cd8432b1d7d0fd8b79e0fc7d10373a8',1,'Voxel::b()'],['../class_escultor.html#a07216dcea8ce9f0942fca3768ed39f6e',1,'Escultor::b()'],['../class_figura_geometrica.html#a25e5d6c21410103c25ec55c0117dac0d',1,'FiguraGeometrica::b()']]]
];
