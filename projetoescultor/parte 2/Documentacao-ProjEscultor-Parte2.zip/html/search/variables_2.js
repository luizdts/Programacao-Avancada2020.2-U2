var searchData=
[
  ['g_128',['g',['../struct_voxel.html#a27c0da1ed2ff430401d23ff171612a73',1,'Voxel::g()'],['../class_escultor.html#af0f8431add4402f8d086b1a9b148d6f9',1,'Escultor::g()'],['../class_figura_geometrica.html#a51930549bcb90d016b824f10f95df355',1,'FiguraGeometrica::g()']]]
];
